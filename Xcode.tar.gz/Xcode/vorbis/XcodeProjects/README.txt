These are modified projects of the ones that come with the official Ogg/Vorbis distribution. They have been altered to allow the building of static libraries and to build Universal Binaries that are compatible with at least OS X 10.2.

To use these, you might try copying over the Xcode projects that ship with the official distribution with these modified versions.

These projects were based on 
libogg-1.1.3
libvorbis-1.1.2

Eric Wing



