SDL_mixer is an example portable sound library for use with SDL.

The source code is available from: http://www.libsdl.org/projects/SDL_mixer

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html

This packages contains the SDL_image.framework for OS X. Conforming with Apple guidelines, this framework contains both the SDL runtime component and development header files.

Requirements:
You must have the SDL.framework installed.

To Install:
Copy the SDL_mixer.framework to /Library/Frameworks

You may alternatively install it in <your home directory>/Library/Frameworks if your access privileges are not high enough. (Be aware that the Xcode templates we provide in the SDL Developer Extras package may require some adjustment for your system if you do this.)


Known Issues:
Mikmod playback seems to be broken (see Bugzilla).
MP3 support is in flux. (See special notes below.)


Special Notes:
In recent history, MP3 support has not been compiled into the SDL_mixer.framework to prevent the need for an external dependency to smpeg. This surprises many people and is often thought of as a bug, so we have begun experimenting with compiling smpeg support in statically like we do with ogg/vorbis. However, because smpeg is C++ based, we are forced to invoke C++ linkage (using the -lstdc++ flag). This may open up a whole can of worms. Also when testing MP3 playback, we encountered run time errors starting with:
Warning: incorrect audio format
mpegtoraw.cpp:487:failed assertion `audio->rawdatawriteoffset > len`
This may mean there is a bug in smpeg itself which makes MP3 playback impossible anyway.
As of this writing, we are still making decisions as to what to support and distribute.


(Partial) History of PB/Xcode projects:
2009-09-21 - Updated for 64-bit (Snow Leopard) Universal Binaries.
	Switched to 10.4 minimum requirement.
	Reebuilt Ogg Vorbis components for 64-bit Universal.
	Ogg 1.1.4
	Vorbis 1.2.3
	Mac native midi had to be disabled because the code depends on legacy Quicktime and won't compile in 64-bit.
	
2006-01-31 - First entry in history. Updated for Universal Binaries. Static libraries of libogg and libvorbis have been brought up-to-date and built as Universal. Infrastructure has been added to support building against smpeg statically, but there may be bugs in smpeg itself (unrelated to static linking) which prevent MP3 playback.
